# Keebio-Parts.pretty
Various KiCAD footprints for mechanical keyboard parts. Accuracy of the footprints are not guaranteed, but a best effort has been made.

License
-------
These files are released under the MIT License.
